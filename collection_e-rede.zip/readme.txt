Siga os passos abaixo para começar a usar as coleções das APIs Rede:

1 - Abra o Postman e selecione a opção “Import” que encontra-se no canto superior esquerdo da tela.
2 - Clique em “Fazer Upload” ou “Upload Files” a escrita vai depender do idioma que você está utilizando, mas via de regra este botão está bem centralizado na página.
3 - Selecione o .json que foi descompactado na mesma pasta desse arquivo.
4 - Informe um nome para sua coleção ou deixe conforme foi importado do arquivo.
5 - Clique sobre a coleção importada e selecione a aba “Variables”.
6 - Informe as credenciais geradas com o projeto.

Para mais detalhes, acesse o Portal do Desenvolvedor: https://developer.userede.com.br/ponto-partida#utilizando-colecao-postman
